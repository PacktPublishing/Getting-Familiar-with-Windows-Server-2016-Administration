Param(
    [Parameter(Mandatory=$true)] [String] $VMName
)

$VMStatus = (Get-VM ${VMName}).State
IF ($VMStatus -eq "Running") {
    Write-Output "Shutting Down Virtual Machine ${VMName}..."
    Stop-Vm ${VMName}
    Do {
        Write-Output "Waiting for shutdown to complete..."
        Sleep -Seconds 5
        $VMStatus = (Get-VM ${VMName}).State
    } While (
        $VMStatus -ne "Off"
    )
}

Write-Output "${VMName} is off. Configuring for Nested Virtualization"

Write-Output "Disabling Dynamic Memory..."
Set-VM -VMName ${VMName} -StaticMemory

# vCPU Configuration 
Write-Output "Checking vCPUs..."
$LogicalProcessors = (Get-VMHost).LogicalProcessors
$VirtualProcessors = (Get-VM -VMName ${VMName}).ProcessorCount
If ($VirtualProcessors -gt '1') {
    Write-Output "No additional processors required. Moving on."
} else {
    Write-Output "Additional processor required. Configuring..."
    Set-VM -VMName ${VMName} -ProcessorCount $($VirtualProcessors + 1)
}

# MAC Spoofing Configuration
If ((Get-VMNetworkAdapter -VMName ${VMName}).MacAddressSpoofing -eq "Off") {
    Write-Output "Configuring MAC Address Spoofing..."
    Set-VMNetworkAdapter -VMName ${VMName} -MacAddressSpoofing On
}

# Enable Virtualization Extensions
If ((Get-VMProcessor -VMName ${VMName}).ExposeVirtualizationExtensions -eq $false) {
    Write-Output "Enabling Virtualization Extensions..."
    Set-VMProcessor -VMName ${VMName} -ExposeVirtualizationExtensions $true
}

# Wrapping Up
Write-Output "Restarting ${VMName}..."
Start-VM -VMName $VMName
